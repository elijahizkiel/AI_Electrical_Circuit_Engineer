# Graphical LTspice Schematic Generation
Generate editable `.asc` schematics for a constrained, verified symbol set. Initial target: resistors, capacitors, and independent voltage sources.
1. Validate the design JSON and supported devices.
2. Verify symbol names and pin coordinates against installed LTspice `.asy` files.
3. Generate symbols, attributes, wires, and ground flags.
4. Open the schematic in LTspice and inspect pin mapping and connectivity.
5. Compare LTspice's generated netlist with the intended design.
The included renderer uses simple placement and is not a general-purpose autorouter. Never claim correctness until the file has been opened and checked in the target LTspice version.
