# Skill: Component Selection
## Purpose
Select components using traceable datasheet information.
## Procedure
1. Identify required electrical parameters.
2. Prefer manufacturer datasheets and official model libraries.
3. Verify voltage/current/power/frequency/temperature limits.
4. Check tolerances and derating.
5. Record manufacturer, part number, model source, and unresolved uncertainties.
## Rules
Never invent datasheet values or SPICE model names. If no verified model exists, mark it as a placeholder and request review.
## Deliverables
BOM with reference designator, value, rating, tolerance, part number/model, and source.
