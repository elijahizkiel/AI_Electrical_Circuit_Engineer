# Proteus Native Schematic Integration
Native project creation is delegated to a version-specific, tested bridge and a blank project template created by that Proteus version. This package provides a handoff bundle, template copying, bridge invocation, and optional launch. It does not fabricate `.pdsprj` internals.
Workflow: record Proteus version; create a blank template; implement and test a supported automation bridge; copy the template; invoke the bridge with the spec and copied project; open the result; inspect symbols, pins, wires, and models; save, close, reopen, and simulate.
Never edit binary project internals with guessed offsets. Do not claim native generation until the project opens and passes checks.
