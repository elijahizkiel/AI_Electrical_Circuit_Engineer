# Skill: Autonomous Circuit Design Engine

## Purpose
Orchestrate a traceable design-to-simulation workflow from a structured, human-reviewed design specification.

## Operating model
The engine is provider-neutral. An LLM may interpret natural-language requirements and propose a candidate JSON specification, but deterministic scripts validate, generate, execute, and report. The LLM must not bypass validation or safety gates.

## Required phases
1. Requirement normalization: identify supply, load, input/output ranges, target metrics, tolerances, simulator, and constraints.
2. Scope gate: allow only low-voltage educational/laboratory simulations in this release. Escalate mains, high-energy, hazardous, safety-critical, or real-world installation requests.
3. Topology proposal: explain the selected topology and alternatives; no unverified model assumptions.
4. Design specification: write the JSON schema used by `examples/rc_lowpass.json`.
5. Static validation: run `scripts/validate_spec.py`.
6. Artifact generation: generate SPICE netlist and optionally LTspice `.asc`.
7. Simulation: run LTspice only when explicitly requested and executable path is configured; otherwise stop after artifact generation.
8. Interpretation: parse `.log` and optional CSV exports.
9. Optimization: run only if an explicit bounded optimization section is present and a corresponding `.meas` result is available.
10. Report: save all artifacts, execution status, evidence, assumptions, and human-review requirements.

## Agent rules
- Never fabricate simulation results or claim a simulation ran when only files were generated.
- Never treat a clean process exit as proof that requirements passed.
- Never modify original source specifications; write derived candidates into a separate run directory.
- Ask for missing critical requirements rather than silently choosing them.
- Do not change topology during parameter optimization.
- Require qualified review before any physical build or connection to hardware.
