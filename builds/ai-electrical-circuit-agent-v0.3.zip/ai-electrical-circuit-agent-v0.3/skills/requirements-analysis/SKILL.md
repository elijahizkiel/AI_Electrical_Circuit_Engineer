# Skill: Requirements Analysis

Convert a natural-language request into a measurable circuit specification.

Capture:
- purpose and operating context,
- input voltage/current range,
- output voltage/current range and load,
- supply constraints,
- bandwidth, ripple, accuracy, response-time or other performance targets,
- allowed component families and preferred simulator,
- environmental and tolerance assumptions.

For each requirement, define a measurable metric, target, units, and tolerance. Mark missing values as unknown and ask targeted questions. Do not invent ratings or datasheet parameters. This release is restricted to low-voltage educational/laboratory simulation.
