# Skill: Schematic and Netlist Generation
## Purpose
Create a readable, electrically consistent circuit representation.
## Current package capability
Generates text SPICE netlists for a limited supported set. It does not yet generate graphical LTspice `.asc` or native Proteus project files.
## Procedure
1. Assign unique reference designators.
2. Define named nets and ground node `0`.
3. Check pin order against the selected model.
4. Generate netlist and annotate each line.
5. Run static validation and simulator syntax checks.
## Acceptance
No floating/unintended nodes, duplicate designators, unsupported devices, or missing ground/reference.
