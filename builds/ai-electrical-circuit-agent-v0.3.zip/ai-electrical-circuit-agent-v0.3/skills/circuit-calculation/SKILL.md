# Skill: Circuit Calculations
## Purpose
Calculate component values and predict expected behavior before simulation.
## Required checks
- DC operating point and bias.
- KCL/KVL at key nodes/loops.
- Component dissipation and rating margin.
- RC/RL time constants and cutoff frequencies where relevant.
- Worst-case tolerance checks where data is available.
## Procedure
Show formulas, substitutions, units, results, and assumptions. Independently sanity-check results before writing the spec.
## Deliverables
Calculation note and expected-value table.
