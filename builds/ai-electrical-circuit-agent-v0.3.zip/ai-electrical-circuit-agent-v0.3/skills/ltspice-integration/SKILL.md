# Skill: LTspice Integration
## Purpose
Run supported SPICE netlists in LTspice and collect evidence.
## Procedure
1. Confirm LTspice is installed and executable path is configured.
2. Generate a `.cir` file with `.end`.
3. Run `scripts/run_ltspice.py`.
4. Inspect `.log`, `.raw`, and any generated netlist.
5. Record simulator version, command, exit code, warnings, and measurements.
## Notes
The adapter uses LTspice batch mode (`-b`). Command-line switches and file behavior can vary across releases; verify against the installed version's help.
## Acceptance
Simulation completed, log reviewed, convergence issues addressed, and measured results compared with requirements.
