# Skill: Circuit Architecture
## Purpose
Select and justify a circuit topology.
## Procedure
1. Convert the request into measurable acceptance criteria.
2. List constraints: supply, load, bandwidth, ripple, accuracy, size, and allowed components.
3. Compare at least two feasible topologies when useful.
4. Select the simplest topology meeting the targets.
5. Define test points and simulation cases.
## Deliverables
Block diagram description, topology rationale, interface/node table, and verification plan.
## Acceptance
Every requirement maps to a design feature and a measurable simulation check.
