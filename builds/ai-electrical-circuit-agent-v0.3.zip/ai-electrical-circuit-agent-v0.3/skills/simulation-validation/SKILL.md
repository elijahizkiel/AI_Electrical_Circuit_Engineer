# Skill: Simulation and Validation
## Purpose
Determine whether simulation evidence supports the design requirements.
## Procedure
1. Choose suitable analyses: `.op`, `.tran`, `.ac`, or `.dc`.
2. Check simulator logs for errors, warnings, convergence problems, and missing models.
3. Compare measured outputs against numeric tolerances.
4. Check component stress under modeled conditions.
5. Run tolerance/sensitivity cases when supported.
6. Separate simulation pass from hardware safety approval.
## Deliverables
Pass/fail matrix, measurements, plots (if available), log summary, and unresolved risks.
## Acceptance
Every requirement has evidence or is explicitly marked unverified. Never report pass based solely on a zero exit code.
