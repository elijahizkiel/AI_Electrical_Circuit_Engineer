# Skill: Electrical Engineering Fundamentals
## Purpose
Translate circuit requirements into a sound low-voltage analog/digital concept.
## Competencies
Ohm's law; KCL/KVL; series/parallel networks; RC/RL response; op-amp fundamentals; diode/transistor basics; logic-level interfaces; power and tolerance calculations.
## Procedure
1. Define reference nodes, input/output, load, and operating range.
2. Draw a block-level architecture before selecting parts.
3. Calculate nominal values with units and significant figures.
4. Check current, voltage, power, and thermal ratings with margin.
5. Identify assumptions and non-ideal effects.
## Deliverables
Topology explanation, equations, node definitions, and an assumptions list.
## Acceptance
All quantities have units; KCL/KVL are consistent; no component exceeds its documented operating ratings in the modeled conditions.
