# Skill: Proteus Integration
## Purpose
Prepare a reproducible handoff for Proteus Design Suite.
## Current package capability
Creates a handoff folder containing the design JSON, SPICE netlist, and instructions. It can optionally launch a user-specified Proteus executable with an existing project. It does not generate native `.pdsprj`/schematic files.
## Procedure
1. Generate and validate the SPICE netlist.
2. Run `scripts/proteus_handoff.py`.
3. In the installed Proteus version, create/open a project and place verified library parts.
4. Wire according to the netlist and verify each device's pin mapping/model.
5. Run the appropriate simulation and record screenshots/logs/measurements.
## Acceptance
Native project opens in the target Proteus version; component models and pin mappings are verified; measured outputs meet requirements.
