import argparse, json, shutil, subprocess
from pathlib import Path

def main():
    p = argparse.ArgumentParser(description="Prepare a Proteus handoff bundle.")
    p.add_argument("spec")
    p.add_argument("--out", required=True)
    p.add_argument("--proteus-exe")
    p.add_argument("--project", help="Path to an existing Proteus project file")
    p.add_argument("--launch", action="store_true")
    p.add_argument("--template-project")
    p.add_argument("--bridge-script")
    a = p.parse_args()
    src = Path(a.spec).resolve()
    out = Path(a.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, out / "design.json")
    d = json.loads(src.read_text(encoding="utf-8"))
    lines = [f"* {d.get('name', 'Circuit handoff')}"]
    for c in d["components"]:
        lines.append(f"{c['ref']} {' '.join(c['nodes'])} {c['value']}")
    for an in d.get("analyses", []):
        lines.append("." + an["type"].lower() + ((" " + an.get("args", "")) if an.get("args") else ""))
    lines.append(".end")
    (out / "design.cir").write_text("\n".join(lines) + "\n", encoding="utf-8")
    note = """# Proteus handoff\n\nThis folder contains the design specification and SPICE reference netlist.\n\nThis utility does not generate a native Proteus schematic/project. In your installed Proteus version, create/open a project, place verified library components, wire them to match `design.cir`, check pin mappings and model compatibility, then simulate. Save the native project from Proteus.\n\nDo not assume SPICE model compatibility across simulators. Verify each model and analysis directive in the installed version.\n"""
    (out / "PROTEUS_HANDOFF.md").write_text(note, encoding="utf-8")
    print("Handoff created:", out)
    if a.template_project:
        template = Path(a.template_project).resolve()
        if not template.is_file(): p.error("Template project does not exist")
        copied = out / template.name
        shutil.copy2(template, copied)
        if a.bridge_script:
            bridge = Path(a.bridge_script).resolve()
            if not bridge.is_file(): p.error("Bridge script does not exist")
            subprocess.run([str(bridge), "--spec", str(out / "design.json"), "--project", str(copied)], check=True)
            print("Bridge completed; verify the project in Proteus.")
    elif a.bridge_script:
        p.error("--bridge-script requires --template-project")
    if a.launch:
        if not a.proteus_exe or not a.project:
            p.error("--launch requires both --proteus-exe and --project")
        exe, project = Path(a.proteus_exe), Path(a.project)
        if not exe.is_file() or not project.is_file():
            p.error("Proteus executable or project path does not exist")
        subprocess.Popen([str(exe), str(project)])
        print("Requested Proteus launch. Confirm the project opened correctly.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
