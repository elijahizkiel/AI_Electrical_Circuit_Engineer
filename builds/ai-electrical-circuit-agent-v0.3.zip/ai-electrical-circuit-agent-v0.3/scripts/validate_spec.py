import argparse, json, re, sys
from pathlib import Path

ALLOWED = {"R": 2, "C": 2, "V": 2}
DIRECTIVES = {"op", "tran", "ac", "dc"}

def main():
    p = argparse.ArgumentParser()
    p.add_argument("spec")
    a = p.parse_args()
    data = json.loads(Path(a.spec).read_text(encoding="utf-8"))
    errors = []
    if not isinstance(data.get("components"), list) or not data["components"]:
        errors.append("components must be a non-empty list")
    refs, nodes = set(), set()
    for i, c in enumerate(data.get("components", [])):
        ref, typ = c.get("ref", ""), c.get("type", "").upper()
        if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", ref):
            errors.append(f"components[{i}]: invalid reference designator")
        if ref.lower() in refs:
            errors.append(f"duplicate reference: {ref}")
        refs.add(ref.lower())
        if typ not in ALLOWED:
            errors.append(f"{ref}: unsupported type {typ}; supported: {sorted(ALLOWED)}")
        if len(c.get("nodes", [])) != ALLOWED.get(typ, -1):
            errors.append(f"{ref}: expected {ALLOWED.get(typ)} nodes")
        if not c.get("value"):
            errors.append(f"{ref}: missing value")
        nodes.update(c.get("nodes", []))
    if "0" not in nodes:
        errors.append("circuit must include ground node '0'")
    for i, an in enumerate(data.get("analyses", [])):
        if an.get("type", "").lower() not in DIRECTIVES:
            errors.append(f"analyses[{i}]: unsupported analysis type")
    if errors:
        print("VALIDATION FAILED")
        for e in errors: print(" -", e)
        return 1
    print(f"VALIDATION PASSED: {len(data['components'])} components, {len(data.get('analyses', []))} analyses")
    print("Scope note: static validation is not electrical verification.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
