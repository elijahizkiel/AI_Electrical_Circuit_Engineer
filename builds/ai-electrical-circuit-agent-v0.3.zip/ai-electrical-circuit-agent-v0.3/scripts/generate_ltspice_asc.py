import argparse,json,re
from pathlib import Path
SYMBOLS={"R":("res",[(0,0),(0,128)]),"C":("cap",[(0,0),(0,128)]),"V":("voltage",[(0,0),(0,128)])}
def tok(v):
 s=str(v)
 if not re.fullmatch(r"[A-Za-z0-9_.+-]+",s): raise ValueError("Unsupported token: "+s)
 return s
def main():
 p=argparse.ArgumentParser(); p.add_argument("spec"); p.add_argument("--out",required=True); a=p.parse_args()
 d=json.loads(Path(a.spec).read_text()); lines=["Version 4","SHEET 1 1200 800"]; nets={}
 for i,c in enumerate(d["components"]):
  t=c["type"].upper()
  if t not in SYMBOLS: raise SystemExit("Unsupported graphical symbol "+t+"; supports R/C/V")
  sym,pins=SYMBOLS[t]; x,y=160+(i%4)*240,128+(i//4)*192
  lines += [f"SYMBOL {sym} {x} {y} R0",f"SYMATTR InstName {tok(c['ref'])}",f"SYMATTR Value {tok(c['value'])}"]
  for node,(px,py) in zip(c["nodes"],pins): nets.setdefault(node,[]).append((x+px,y+py))
 for idx,(node,pts) in enumerate(nets.items()):
  if node=="0":
   for x,y in pts: lines.append(f"FLAG {x} {y} 0")
   continue
  by=640+idx*32
  for x,y in pts:
   if y!=by: lines.append(f"WIRE {x} {y} {x} {by}")
  xs=[x for x,y in pts]
  if min(xs)!=max(xs): lines.append(f"WIRE {min(xs)} {by} {max(xs)} {by}")
  lines.append(f"FLAG {min(xs)} {by} {tok(node)}")
 out=Path(a.out); out.parent.mkdir(parents=True,exist_ok=True); out.write_text("\\n".join(lines)+"\\n")
 print("Wrote",out,"— verify symbol pin geometry and connectivity in LTspice.")
if __name__=="__main__": main()
