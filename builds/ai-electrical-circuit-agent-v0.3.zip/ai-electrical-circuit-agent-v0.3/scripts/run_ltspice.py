import argparse, os, shutil, subprocess, sys
from pathlib import Path

def main():
    p = argparse.ArgumentParser(description="Run an LTspice netlist in batch mode.")
    p.add_argument("netlist")
    p.add_argument("--exe", default=os.environ.get("LTSPICE_EXE"))
    p.add_argument("--timeout", type=int, default=180)
    a = p.parse_args()
    net = Path(a.netlist).resolve()
    if not net.is_file():
        p.error(f"netlist not found: {net}")
    exe = a.exe or shutil.which("LTspice") or shutil.which("ltspice")
    if not exe:
        p.error("Set LTSPICE_EXE to the installed executable path.")
    cmd = [str(exe), "-b", str(net)]
    print("Running:", cmd)
    try:
        result = subprocess.run(cmd, cwd=str(net.parent), timeout=a.timeout, check=False)
    except subprocess.TimeoutExpired:
        print("ERROR: LTspice timed out; inspect the project and simulator state.")
        return 124
    print("LTspice exit code:", result.returncode)
    for ext in (".log", ".raw", ".net"):
        f = net.with_suffix(ext)
        print(f"{ext}: {'created' if f.exists() else 'not found'} — {f}")
    print("Review the simulator log and measurements; exit code alone is not a pass.")
    return result.returncode

if __name__ == "__main__":
    sys.exit(main())
