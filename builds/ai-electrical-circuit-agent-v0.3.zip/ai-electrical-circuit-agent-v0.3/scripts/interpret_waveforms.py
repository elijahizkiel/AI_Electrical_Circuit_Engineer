import argparse,csv,json,re
from pathlib import Path
def readlog(path):
 t=Path(path).read_text(errors="replace"); m={}
 for line in t.splitlines():
  x=re.search(r"^\s*([A-Za-z][\w]*)\s*[:=]\s*([-+0-9.eE]+)",line)
  if x:
   try:m[x.group(1)]=float(x.group(2))
   except ValueError:pass
 alerts=[s.strip() for s in t.splitlines() if re.search(r"error|warning|timestep too small|singular matrix",s,re.I)]
 return m,alerts
def readcsv(path):
 with open(path,newline="",encoding="utf-8-sig") as f: rows=list(csv.DictReader(f))
 if not rows: raise ValueError("CSV has no data")
 x=list(rows[0])[0]; out={}
 for k in list(rows[0])[1:]:
  vals=[]
  for r in rows:
   try:vals.append(float(r[k]))
   except (ValueError,TypeError):pass
  if vals:out[k]={"samples":len(vals),"min":min(vals),"max":max(vals),"mean":sum(vals)/len(vals),"peak_to_peak":max(vals)-min(vals),"last":vals[-1]}
 return x,out
def main():
 p=argparse.ArgumentParser();p.add_argument("--log");p.add_argument("--csv");p.add_argument("--out",default="waveform_report.json");a=p.parse_args()
 if not a.log and not a.csv:p.error("Supply --log and/or --csv")
 r={"measurements":{},"warnings_errors":[],"waveforms":{},"limitations":["Simulation results are not physical measurements or hardware safety certification."]}
 if a.log:r["measurements"],r["warnings_errors"]=readlog(a.log)
 if a.csv:r["x_axis"],r["waveforms"]=readcsv(a.csv)
 Path(a.out).write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
if __name__=="__main__":main()
