import argparse
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

def run(cmd, cwd=None):
    p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    return {"command": [str(x) for x in cmd], "returncode": p.returncode,
            "stdout": p.stdout[-6000:], "stderr": p.stderr[-6000:]}

def main():
    ap = argparse.ArgumentParser(description="Provider-neutral circuit design workflow orchestrator")
    ap.add_argument("spec", help="Reviewed circuit JSON specification")
    ap.add_argument("--out", default="runs/run_001")
    ap.add_argument("--simulator", choices=["none", "ltspice", "proteus-handoff"], default="none")
    ap.add_argument("--ltspice-exe", default=os.environ.get("LTSPICE_EXE"))
    ap.add_argument("--generate-asc", action="store_true")
    ap.add_argument("--waveform-csv", help="Optional CSV exported by the simulator")
    ap.add_argument("--proteus-template")
    ap.add_argument("--proteus-bridge")
    args = ap.parse_args()

    spec_path = Path(args.spec).resolve()
    if not spec_path.is_file():
        ap.error(f"Specification not found: {spec_path}")
    spec = json.loads(spec_path.read_text(encoding="utf-8"))

    # Conservative scope gate. This is a keyword safety net, not an engineering certification.
    blob = json.dumps(spec).lower()
    blocked = ["mains", "230vac", "120vac", "high voltage installation",
               "high-energy", "high energy", "safety-critical", "safety critical"]
    hits = [term for term in blocked if term in blob]
    if hits:
        print("STOP: this release does not automate mains, high-energy, or safety-critical designs.")
        print("Flagged terms:", ", ".join(hits))
        return 3

    out = Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    shutil.copy2(spec_path, out / "input_spec.json")
    report = {
        "package_version": "0.3.0",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "input_spec": str(spec_path),
        "output_directory": str(out),
        "simulator_requested": args.simulator,
        "phases": [],
        "simulation_performed": False,
        "requirements_passed": None,
        "human_review_required_before_hardware": True,
        "limitations": [
            "Simulation is not physical measurement or proof of hardware safety.",
            "This release supports a constrained SPICE component set.",
            "Native Proteus schematic generation requires a tested, version-specific bridge."
        ]
    }

    def phase(name, result):
        report["phases"].append({"name": name, **result})
        return result.get("returncode", 0) == 0

    validate = phase("validate_spec", run([sys.executable, str(Path(__file__).with_name("validate_spec.py")), str(spec_path)]))
    if not validate:
        (out / "report.json").write_text(json.dumps(report, indent=2))
        return 2

    netlist = out / "design.cir"
    gen = phase("generate_spice", run([sys.executable, str(Path(__file__).with_name("generate_spice.py")),
                                      str(spec_path), "--out", str(netlist)]))
    if not gen:
        (out / "report.json").write_text(json.dumps(report, indent=2))
        return 2

    if args.generate_asc:
        asc = out / "design.asc"
        phase("generate_ltspice_asc", run([sys.executable, str(Path(__file__).with_name("generate_ltspice_asc.py")),
                                           str(spec_path), "--out", str(asc)]))

    if args.simulator == "ltspice":
        if not args.ltspice_exe:
            report["phases"].append({"name": "ltspice", "status": "not_run", "reason": "Set --ltspice-exe or LTSPICE_EXE"})
        else:
            result = run([sys.executable, str(Path(__file__).with_name("run_ltspice.py")),
                          str(netlist), "--exe", args.ltspice_exe])
            phase("ltspice", result)
            report["simulation_performed"] = result["returncode"] == 0
            log = netlist.with_suffix(".log")
            if log.exists():
                wave_cmd = [sys.executable, str(Path(__file__).with_name("interpret_waveforms.py")),
                            "--log", str(log), "--out", str(out / "waveform_report.json")]
                if args.waveform_csv:
                    wave_cmd += ["--csv", str(Path(args.waveform_csv).resolve())]
                phase("interpret_waveforms", run(wave_cmd))
    elif args.simulator == "proteus-handoff":
        cmd = [sys.executable, str(Path(__file__).with_name("proteus_handoff.py")),
               str(spec_path), "--out", str(out / "proteus_handoff")]
        if args.proteus_template:
            cmd += ["--template-project", args.proteus_template]
        if args.proteus_bridge:
            cmd += ["--bridge-script", args.proteus_bridge]
        phase("proteus_handoff", run(cmd))

    report["artifacts"] = [str(p.relative_to(out)) for p in out.rglob("*") if p.is_file() and p.name != "report.json"]
    report["requirements_passed"] = None  # Requires explicit metric-to-measurement mapping and reviewed limits.
    report["final_status"] = "artifacts_generated_simulation_not_run"
    if report["simulation_performed"]:
        report["final_status"] = "simulation_executed_results_require_review"
    (out / "report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
