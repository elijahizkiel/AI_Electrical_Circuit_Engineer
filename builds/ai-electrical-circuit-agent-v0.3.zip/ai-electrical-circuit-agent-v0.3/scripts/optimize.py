import argparse,copy,itertools,json,re,subprocess,sys
from pathlib import Path
def measure(path,name):
 t=Path(path).read_text(errors="replace");m=re.search(rf"(?im)^\s*{re.escape(name)}\s*[:=]\s*([-+0-9.eE]+)",t)
 if not m:raise ValueError(f"Measurement {name!r} not found")
 return float(m.group(1))
def main():
 p=argparse.ArgumentParser();p.add_argument("spec");p.add_argument("--ltspice-exe",required=True);p.add_argument("--out",default="optimization_results");p.add_argument("--max-candidates",type=int,default=25);a=p.parse_args()
 base=json.loads(Path(a.spec).read_text());o=base.get("optimization")
 if not o:p.error("Missing optimization object")
 obj=o["objective"]
 if obj.get("mode")!="minimize_absolute_error":p.error("Only minimize_absolute_error supported")
 params=o.get("parameters",[])
 if not params:p.error("No optimization parameters")
 ranges=[]
 for q in params:
  lo,hi,step=float(q["min"]),float(q["max"]),float(q["step"])
  if step<=0 or hi<lo:p.error("Invalid bounds")
  v=[];x=lo
  while x<=hi+step*1e-9 and len(v)<a.max_candidates:v.append(round(x,12));x+=step
  ranges.append(v)
 combos=list(itertools.islice(itertools.product(*ranges),a.max_candidates));out=Path(a.out);out.mkdir(parents=True,exist_ok=True);results=[]
 for i,combo in enumerate(combos):
  vals={q["ref"]:v for q,v in zip(params,combo)};spec=copy.deepcopy(base);found=set()
  for c in spec["components"]:
   if c["ref"] in vals:c["value"]=str(vals[c["ref"]]);found.add(c["ref"])
  if found!=set(vals):raise ValueError("Optimization reference not found")
  w=out/f"candidate_{i:03d}";w.mkdir(exist_ok=True);sf=w/"design.json";sf.write_text(json.dumps(spec,indent=2));net=w/"design.cir"
  subprocess.run([sys.executable,str(Path(__file__).with_name("generate_spice.py")),str(sf),"--out",str(net)],check=True)
  run=subprocess.run([sys.executable,str(Path(__file__).with_name("run_ltspice.py")),str(net),"--exe",a.ltspice_exe])
  try:
   val=measure(net.with_suffix(".log"),obj["measurement"]);results.append({"values":vals,"measurement":val,"score":abs(val-float(obj["target"])),"exit_code":run.returncode})
  except Exception as e:results.append({"values":vals,"error":str(e),"exit_code":run.returncode})
 valid=[x for x in results if "score" in x];report={"objective":obj,"results":results,"best":min(valid,key=lambda x:x["score"]) if valid else None,"warning":"Simulation-only; independently review models, ratings, tolerances and hardware safety."}
 (out/"summary.json").write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));return 0 if valid else 2
if __name__=="__main__":raise SystemExit(main())
