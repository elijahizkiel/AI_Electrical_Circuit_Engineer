import argparse, json
from pathlib import Path

def main():
    p = argparse.ArgumentParser()
    p.add_argument("spec")
    p.add_argument("--out", required=True)
    a = p.parse_args()
    d = json.loads(Path(a.spec).read_text(encoding="utf-8"))
    lines = [f"* {d.get('name', 'AI-generated circuit')}", "* Generated from JSON specification"]
    for c in d["components"]:
        typ = c["type"].upper()
        nodes = " ".join(c["nodes"])
        lines.append(f"{c['ref']} {nodes} {c['value']}")
    for an in d.get("analyses", []):
        typ = an["type"].lower()
        args = an.get("args", "").strip()
        lines.append("." + typ + ((" " + args) if args else ""))
    lines.append(".end")
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Wrote {out.resolve()}")

if __name__ == "__main__":
    main()
