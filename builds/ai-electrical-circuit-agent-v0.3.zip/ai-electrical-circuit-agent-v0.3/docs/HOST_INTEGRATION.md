# Host integration guide

## Provider-neutral contract
The host agent is responsible for language understanding and proposing a JSON specification. The deterministic Python tools are responsible for validation, file generation, simulation invocation, and report assembly.

## Suggested tool interface
Expose these commands as separate, permissioned tools:
- `validate_spec(spec_path)`
- `generate_spice(spec_path, output_path)`
- `generate_ltspice_asc(spec_path, output_path)`
- `run_ltspice(netlist_path, executable_path)`
- `proteus_handoff(spec_path, output_directory, template, bridge)`
- `interpret_waveforms(log_path, csv_path, output_path)`
- `design_agent(spec_path, output_directory, simulator)`

## Host mapping
- Codex/Claude Code/Cursor: load `AGENT.md` and relevant `skills/*/SKILL.md` as project instructions or skill files according to the host's current conventions.
- Custom Python agent: load Markdown files as context and call scripts with subprocess under an allowlisted workspace.
- Other agents: preserve the same inputs, outputs, and safety gates.

## Approval boundaries
Require user approval before running desktop automation, writing outside the workspace, overwriting files, downloading models, or connecting to hardware. Do not expose arbitrary shell execution as an agent tool.
