# AI Electrical Circuit Design Agent

Portable, provider-neutral starter kit for an AI agent that designs **low-voltage educational/laboratory circuits**, generates SPICE netlists, runs LTspice, and prepares a Proteus handoff.

## What is included
- Eight focused `SKILL.md` files with role, workflow, inputs, outputs, and acceptance checks.
- A machine-readable circuit specification format.
- A conservative SPICE netlist generator for a deliberately small supported component set.
- An LTspice batch-run adapter.
- A Proteus handoff adapter. It creates a project handoff folder and can launch a user-specified Proteus executable; it does **not** pretend to generate native Proteus `.pdsprj` files.
- Example RC low-pass circuit and validation script.

## Important scope and safety
This starter kit is for low-voltage educational/lab simulations. It is not an electrical installation design tool and must not be used to construct or test mains-connected, high-energy, high-temperature, or safety-critical circuits. Do not connect a simulated design to real hardware without qualified adult/instructor/engineering review, suitable isolation, current limiting, and proper lab procedures. Simulation is not proof of hardware safety.

The generator intentionally supports only a small subset (resistors, capacitors, independent DC voltage sources, ground, and transient/AC/DC operating-point directives). Extend it only with verified models and tests. The agent must stop and request human review when a request is outside scope, a model is missing, or requirements conflict.

## Quick start (Python 3.10+)

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt

python scripts/validate_spec.py examples/rc_lowpass.json
python scripts/generate_spice.py examples/rc_lowpass.json --out build/rc_lowpass.cir
```

### Run with LTspice
Install LTspice from Analog Devices, then set the executable path:

```bash
# Windows PowerShell example (use your actual installation path)
$env:LTSPICE_EXE = "C:\Program Files\ADI\LTspice\LTspice.exe"
python scripts/run_ltspice.py build/rc_lowpass.cir
```

The adapter invokes LTspice batch mode (`-b`) and expects LTspice to produce its normal output files. Check the `.log` and `.raw` files after execution. See `skills/ltspice-integration/SKILL.md`.

### Prepare a Proteus handoff
Install Proteus separately. The adapter packages the generated netlist, JSON specification, and a handoff note:

```bash
python scripts/proteus_handoff.py examples/rc_lowpass.json --out build/proteus_handoff
```

Optionally launch a local Proteus executable with an existing project file:

```bash
python scripts/proteus_handoff.py examples/rc_lowpass.json \
  --out build/proteus_handoff \
  --proteus-exe "C:\Program Files (x86)\Labcenter Electronics\Proteus 8 Professional\BIN\PDS.exe" \
  --project "C:\path\to\your-existing-project.pdsprj" --launch
```

Proteus native project automation and file formats vary by version/licence. This adapter does not fabricate a native schematic. Create/verify the schematic in Proteus using the handoff netlist and the installed version's supported workflow.

## Provider-neutral agent integration
Use `AGENT.md` as the system-level orchestration contract. Each folder in `skills/` is a modular skill. An agent host can load all `SKILL.md` files or select them by task. The scripts are callable tools, not autonomous authority.

Recommended host choices:
- **Codex / Claude Code / Cursor:** expose each skill folder as project instructions or skills according to that host's current format.
- **Custom Python agent:** read `AGENT.md`, load the relevant skill files, and call scripts through a controlled tool layer.
- **Other hosts:** map the same roles to their own instruction/tool format.

Do not assume every host supports the same skill-discovery convention. Keep these Markdown files as the canonical source and adapt wrappers as needed.

## Workflow
1. Clarify measurable requirements and constraints.
2. Select a topology and explain assumptions.
3. Calculate nominal component values and check ratings.
4. Generate a structured design spec and SPICE netlist.
5. Run syntax/static checks.
6. Simulate in LTspice or prepare Proteus handoff.
7. Compare measurements with target tolerances.
8. Iterate only within approved constraints.
9. Produce a report with assumptions, limitations, and human-review items.

## Files
- `AGENT.md` — main orchestration contract.
- `skills/*/SKILL.md` — specialist skills.
- `scripts/` — runnable utilities.
- `examples/rc_lowpass.json` — safe example.
- `config/policy.json` — scope and safety policy.

## Known limitations
- The initial generator is not a general-purpose schematic router and does not create graphical LTspice `.asc` files.
- The Proteus adapter is a handoff/launch helper, not a native Proteus schematic generator.
- `.raw` parsing and automatic waveform optimization are not implemented in this starter version. Use LTspice's log/measurement outputs and add a tested raw-data parser before enabling automated waveform-based optimization.
- Real component models, tolerances, temperature effects, PCB parasitics, and manufacturing constraints require additional validation.

## v0.2 additions

- **Graphical LTspice:** `python scripts/generate_ltspice_asc.py examples/rc_lowpass.json --out build/rc_lowpass.asc`. Supports only R/C/V symbols with a simple placement strategy. Open and verify the schematic before use.
- **Waveform interpretation:** export simulator traces to CSV, then run `python scripts/interpret_waveforms.py --log build/rc_lowpass.log --csv build/traces.csv --out build/report.json`. Binary RAW parsing is not included.
- **Optimization:** add an `optimization` object with objective mode `minimize_absolute_error`, measurement name, target, and parameter min/max/step. Include a matching `.meas` directive. Run `python scripts/optimize.py design.json --ltspice-exe /path/to/LTspice`. This is a bounded sweep.
- **Proteus native bridge:** `proteus_handoff.py` accepts `--template-project` and `--bridge-script`. The template must be created by the installed Proteus version; the bridge must be user-supplied and version-tested. No universal `.pdsprj` writer is claimed.


## Version 0.3: Autonomous workflow orchestrator

The new `scripts/design_agent.py` coordinates the validated stages without depending on a specific LLM provider.

Generate artifacts only:
```bash
python scripts/design_agent.py examples/rc_lowpass_agent_spec.json --out runs/demo --generate-asc
```

Run LTspice (after installation and path configuration):
```bash
# Windows PowerShell
$env:LTSPICE_EXE = "C:\Program Files\ADI\LTspice\LTspice.exe"
python scripts/design_agent.py examples/rc_lowpass_agent_spec.json --out runs/ltspice_demo --simulator ltspice --generate-asc
```

Prepare Proteus handoff:
```bash
python scripts/design_agent.py examples/rc_lowpass_agent_spec.json --out runs/proteus_demo --simulator proteus-handoff
```

The orchestrator creates `report.json`. It never claims requirements passed automatically unless a future, explicitly configured metric-to-measurement verification layer is added. It does not automatically run optimization in this release; use the separate bounded optimizer only after a matching `.meas` directive and reviewed objective are present.

See `docs/HOST_INTEGRATION.md` for Codex, Claude Code, Cursor, and custom Python agent integration.
